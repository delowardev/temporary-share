<?php
/**
 * Plugin manifest class.
 *
 * @package content-sliders
 */

namespace Tiny\Slider\Inc;

use \Tiny\Slider\Inc\Traits\Singleton;

/**
 * Class Plugin
 */
class Plugin {

	use Singleton;

	/**
	 * Construct method.
	 */
	protected function __construct() {

		// Load plugin classes.
		Assets::get_instance();
		Blocks::get_instance();

	}

}
