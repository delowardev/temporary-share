=== Content Sliders - Essential Slider Block ===
Contributors: delowardev
Tags: blocks, gutenberg, gutenberg blocks, editor, block, page builder
Author URI:  https://delowar.dev/
Tags: Page builder, Gutenberg blocks, WordPress blocks, gutenberg, blocks
Requires at least: 5.5
Tested up to: 6.3
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tiny, powerful, and super-fast Gutenberg essential blocks.

== Description ==

ContentSliders is a minimal and powerful WordPress content slider for Gutenberg editor.

== Features ==

* Slideshow any blocks.
* Unlimited slideshows.
* Different types of animations: `fade`, `slide`, and `flip`.
* Block alignment: wide, full.
* Arrow customization support.
* Pagination dots customizations support.

== Installation ==

1. Upload the `content-sliders` folder to your `/wp-content/plugins/` directory or alternatively upload the content-sliders.zip file via the plugin page of WordPress by clicking 'Add New' and selecting the zip from your computer.
3. Activate the ContentSliders WordPress plugin through the 'Plugins' menu in WordPress.
4. Use ContentSliders blocks on your next page or post.

## ContentSliders features
- **Slider:**  Display multiple content or images in a beautiful slideshow.

== Changelog ==

= 1.0.0 =
Initial Release


== Screenshots ==

1-Preview. screenshot-01.jpeg
