import {
	BlockControls,
	ButtonBlockAppender,
	store as blockEditorStore,
	useBlockProps,
	useInnerBlocksProps
} from "@wordpress/block-editor";
import Inspector from "./inspector";
import {useEffect, useMemo, useRef, useState} from "@wordpress/element";
import {useDispatch, useSelect} from "@wordpress/data";
import {ToolbarButton, ToolbarGroup} from "@wordpress/components";
import {edit as editIcon} from '@wordpress/icons';
import {__} from "@wordpress/i18n";
import classnames from "classnames";

const allowedBlocks = [ 'content-sliders/slide' ];
const template = [
	[ "content-sliders/slide", { align: "wide"} ]
];

export default function edit( props ) {
	
	const {
		clientId,
		isSelected,
		attributes,
		attributes: {
			pagination,
			navigation,
			isEditing: isBlockEditing,
			minHeight,
			minHeightUnit,
			autoplay,
			autoplayDelay,
			pauseOnMouseEnter,
			effect,
			loop,
			speed,
			colors
		},
		setAttributes
	} = props;
	
	const swiper = useRef( null );
	const _navigation_prev = useRef( null );
	const _navigation_next = useRef( null );
	const _pagination = useRef( null );
	const instance = useRef( null )
	const [ isEditing, setEditing] = useState( false )
	const { updateBlockAttributes } = useDispatch( blockEditorStore );
	
	const blockProps = useBlockProps({
		className: 'content-sliders-slider'
	});
	
	const { children, ...innerBlockProps } = useInnerBlocksProps( blockProps, {
		allowedBlocks,
		template,
		renderAppender: false
	} );
	
	useEffect( () => {
		setAttributes({ isEditing })
	}, [ isEditing ])
	
	const settings = useMemo(() => {
		
		const _autoplay = {
			delay: autoplayDelay,
			pauseOnMouseEnter
		}
		
		let effect2 = {};
		
		if ( effect === 'fade' ) {
			effect2 = {
				effect: 'fade',
				fadeEffect: {
					crossFade: true
				}
			}
		}
		
		if ( effect === 'flip') {
			effect2 = {
				effect: 'flip',
				flipEffect: {
					slideShadows: false,
				},
			}
		}
		
		return {
			autoplay: autoplay ? _autoplay : false,
			loop,
			speed,
			...effect2
		}
	}, [
		autoplay,
		autoplayDelay,
		pauseOnMouseEnter,
		loop,
		speed,
		effect,
	]);
	
	useEffect( () => {
		
		if ( isBlockEditing ) {
			return;
		}
		
		rebuild();
		
	}, [ settings ]);
	
	
	function destroy() {
		instance.current?.destroy();
	}
	
	function rebuild() {
		
		if ( ! Swiper ) {
			console.warn("Swiper not found");
			return;
		}
		
		
		if (  ! swiper.current ) {
			console.warn("Swiper element not found");
			return;
		}
		
		if ( instance.current ) {
			destroy();
		}
		
		instance.current = new Swiper( swiper.current, {
			slidesPerView: 1,
			autoHeight: true,
			observeSlideChildren: true,
			preventClicks: false,
			allowTouchMove: false,
			pagination: {
				el: _pagination?.current,
				clickable: true
			},
			navigation: {
				nextEl: _navigation_next?.current,
				prevEl: _navigation_prev?.current,
			},
			...settings
		} );
	}
	
	useEffect( () => {
		
		if ( isBlockEditing ) {
			destroy();
			return;
		}
		
		rebuild();
		return destroy
		
		
	}, [ swiper.current, isBlockEditing ])
	
	
	
	const innerBlockIds = useSelect( select => {
		return select( blockEditorStore).getBlock( clientId ).innerBlocks.map( block => block.clientId );
	} )
	
	const innerBlocksLen = innerBlockIds.length;
	
	const blockJustInserted = useSelect( select => {
		const { wasBlockJustInserted } =  select( blockEditorStore);
		return select(blockEditorStore).getBlock(clientId).innerBlocks?.flatMap(block => {
			if (  wasBlockJustInserted(block.clientId)  ) {
				return block?.clientId
			}
			return [];
		}) || []
	} );
	
	const { getBlock } = useSelect( select => select( blockEditorStore ) );
	
	useEffect( () => {
		
		if ( blockJustInserted?.length && minHeight ) {
			setTimeout( () => {
				const cover = getBlock( blockJustInserted[0] )?.innerBlocks?.[0]
				updateBlockAttributes( cover?.clientId, { minHeight, minHeightUnit } )
			}, 10 )
		}

	}, [ blockJustInserted ])
	
	useEffect( () => {
		setTimeout( () => {
			instance.current?.updateSlides();
			instance.current?.slideTo( innerBlocksLen - 1, 0 );
		}, 50)
	}, [ innerBlocksLen ])
	
	useEffect( () => {
		rebuild();
	}, [ innerBlockIds ] )
	
	const colorStyles = Object.fromEntries( Object.keys( colors ).map( key => typeof colors[key] ? [ `--tns-` + key, colors[key] ] : [] ) );
	
	const otherStyles = Object.fromEntries(
		[
			'arrowSize',
			'arrowPadding',
			'arrowRadius',
			'arrowOffset',
			'dotsSize',
			'dotsOffset',
			'dotsGap',
			'arrowStyle'
		].map( key => {
			return typeof attributes[key] !== "undefined" ? [ '--tns-' + key, attributes[key] + 'px' ] : []
		} )
	)
	
	const style = {
		...colorStyles,
		...otherStyles,
		...( innerBlockProps?.style ? innerBlockProps?.style : {} )
	}
	
	return (
		<div { ...innerBlockProps } style={ style }>
			
			{ isSelected && <Inspector { ...props } /> }
			
			{
				isSelected && (
					<BlockControls group="block">
						<ToolbarGroup>
							<ToolbarButton
								isActive={ isEditing }
								icon={ editIcon }
								label={ isEditing ? __( 'Exit edit', 'content-sliders' ) : __( 'Edit', 'content-sliders' ) }
								onClick={ () => setEditing( ( p ) => ! p ) }
							/>
						</ToolbarGroup>
					</BlockControls>
				)
			}
			
			<div ref={ swiper } className={ classnames({ 'swiper': ! isBlockEditing }) }>
				<div className={ classnames({ 'swiper-wrapper': ! isBlockEditing }) }>
					{ children }
				</div>
				
				
				<div
					style={{ display: ( isBlockEditing || ! pagination  ) ? 'none': '' }}
					ref={ _pagination }
					className="swiper-pagination"
				/>
				
				{
					<div style={{ display: ( isBlockEditing || ! navigation  ) ? 'none': '' }}>
						<div ref={ _navigation_prev } className="swiper-button-prev" />
						<div ref={ _navigation_next } className="swiper-button-next" />
					</div>
				}
				
			</div>
			
			<div className="content-sliders-slider-appender">
				<ButtonBlockAppender rootClientId={ clientId } />
			</div>
		</div>
	);
}
