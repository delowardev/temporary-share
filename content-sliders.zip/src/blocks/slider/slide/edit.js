import { useInnerBlocksProps, useBlockProps, ButtonBlockAppender, store as blockEditorStore } from "@wordpress/block-editor";
import {useDispatch, useSelect} from "@wordpress/data";
import {useEffect, useRef, useCallback} from "@wordpress/element";
import classnames from "classnames";
import { debounce } from "lodash";

const allowedBlocks = [ "core/cover" ];


const template = [
	[
		"core/cover",
		{
			overlayColor: "light-green-cyan"
		},
		[
			[
				"core/heading",
				{
					textAlign: "center"
				}
			]
		]
	]
]


export default function edit({  clientId, context, isSelected, attributes }) {
	
	const isBlockEditing = context['content-sliders/slider/is-editing'];
	const minHeight = context['content-sliders/slider/min-height'];
	const minHeightUnit = context['content-sliders/slider/min-height-unit'];
	
	const blockProps = useBlockProps({
		className: classnames('content-sliders-slide', { 'swiper-slide': ! isBlockEditing })
	});
	
	const elem = useRef( null );
	
	const { updateBlockAttributes } = useDispatch( blockEditorStore );
	
	const { children, ...innerBlockProps } = useInnerBlocksProps( blockProps, {
		allowedBlocks,
		template
	} );
	
	const { blockIndex, isBlockSelected } = useSelect( select => {
		const { getBlockIndex, getBlockHierarchyRootClientId, getSelectedBlockClientId } = select( blockEditorStore);
		const rootClientId = getBlockHierarchyRootClientId( clientId );
		const selectedRootClientId = getBlockHierarchyRootClientId( getSelectedBlockClientId() );
		
		return {
			blockIndex: getBlockIndex( clientId ),
			isBlockSelected: rootClientId === selectedRootClientId,
		}
	} )
	
	const innerBlockIDs = useSelect( ( select ) => {
		const { getBlock } = select( blockEditorStore );
		const innerBlocks = getBlock( clientId )?.innerBlocks;
		return innerBlocks?.map( block => block?.clientId ) || [];
	}, [ clientId ]);
	
	const wasBlockJustInserted = useSelect( ( select ) => {
		const { wasBlockJustInserted } = select( blockEditorStore );
		return wasBlockJustInserted( clientId )
	}, [ clientId ]);
	
	useEffect( () => {
		updateBlockAttributes( innerBlockIDs, { lock: { move: true, remove: true  }} )
	}, [ innerBlockIDs ]);
	
	
	const coverHeight = useSelect( select => {
		return select( blockEditorStore ).getBlock( clientId )?.innerBlocks?.[0]?.attributes?.minHeight;
	} );
	
	const updateWithDebounce = useCallback(
		debounce(function () {
				elem.current?.closest(".swiper")?.swiper?.updateAutoHeight(50);
			}, 200 ),
		[]
	)
	
	useEffect( () => {
		updateBlockAttributes( innerBlockIDs, { minHeight, minHeightUnit } );
		updateWithDebounce();
		
	}, [ minHeight, minHeightUnit ]);
	
	
	useEffect( () => {
		updateWithDebounce();
	}, [ coverHeight ])
	
	
	useEffect( () => {
		if ( isBlockSelected || wasBlockJustInserted ) {
			setTimeout( () => elem.current?.closest(".swiper")?.swiper?.slideTo( blockIndex ), 50);
		}
	}, [ isBlockSelected, blockIndex, wasBlockJustInserted ])
	
	const showAppender = useSelect( select => {
		return ! select( blockEditorStore ).getBlock( clientId )?.innerBlocks.length
	} )
	
	return (
		<div {...innerBlockProps}>
			<span ref={ elem } />
			{ children }
			{
				showAppender && (
					<div className="content-sliders-slide-appender">
						<ButtonBlockAppender rootClientId={ clientId } />
					</div>
				)
 			}
		</div>
	);
}
