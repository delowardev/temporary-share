/**
 * All blocks scripts imports.
 *
 * @package content-sliders
 */

// load blocks
import "./slider"
