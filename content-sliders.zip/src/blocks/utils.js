export const generateColorVars = ( colors = {} ) => {
	return Object.fromEntries(Object.keys( colors || {} ).map( k => {
		return [ '--' + k, colors[k] ]
	} ))
}
